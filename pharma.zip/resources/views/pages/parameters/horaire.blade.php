                <!-- partial -->
                @extends('layouts.app')

                @section('content')  
                <div class="page-content">
                    <section class="section-produit mt-3 pb-5">
                        <div class="row text-end">
                            <div class="col-md-12">
                                <div class="buttons">
                                    <a href="updatehoraire" class="btn-hover color-green">Modifier</a>
                                </div>
                            </div>
                        </div>

                        <div class="section-table-product section-horaire mt-4 pt-3">
                            <div class="row filtre-product pb-1">
                                <div class="col-md-12">
                                    <div class="title-p pt-1"><h5>Heures d'ouverture par défaut</h5></div>
                                </div>
                            </div>
                            <table id="" class="tables table-striped" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>Jour</th>
                                        <th>Heures d'ouverture</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="" role="button">
                                        <td>Lundi</td>
                                        <td>07:45 - 13:00 | 15:30 - 20:00</td>
                                    </tr>
                                    <tr class="" role="button">
                                        <td>Mardi</td>
                                        <td>07:45 - 13:00 | 15:30 - 20:00</td>
                                    </tr>
                                    <tr class="" role="button">
                                        <td>Mercredi</td>
                                        <td>07:45 - 13:00 | 15:30 - 20:00</td>
                                    </tr>
                                    <tr class="" role="button">
                                        <td>Jeudi</td>
                                        <td>07:45 - 13:00 | 15:30 - 20:00</td>
                                    </tr>
                                    <tr class="" role="button">
                                        <td>Vendredi</td>
                                        <td>07:45 - 13:00 | 15:30 - 20:00</td>
                                    </tr>
                                    <tr class="" role="button">
                                        <td>Samedi</td>
                                        <td>07:45 - 13:00 | 15:30 - 20:00</td>
                                    </tr>
                                    <tr class="" role="button">
                                        <td>Dimanche</td>
                                        <td>07:45 - 13:00 | 15:30 - 20:00</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>
                @endsection
          