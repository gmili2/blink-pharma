
             
                @extends('layouts.app')

                @section('content')     
                <div class="page-content">
                    <section class="section-client mt-3 pb-5">
                        <form action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="title">
                                        <h1>Créer un cadeau de points de fidélité</h1>
                                    </div>
                                </div>
                                <div class="col-md-6 text-end">
                                    <div class="buttons">
                                        <a href="#" class="btn-hover color-green">Sauvegarder</a>
                                    </div>
                                </div>
                            </div>
                            <div class="section-form-client mt-4">
                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Options</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <label class="form-label">Type *</label>
                                            <select class="form-select" id="type" name="type">
                                                <option value="produit">Produit</option>
                                                <option value="avoir">Avoir</option>
                                            </select>
                                        </div>
                                        <div class="col-md-12 mb-3" id="produit-filter">
                                            <label class="form-label">Produit</label>
                                            <input type="text" class="form-control" id="nom-produit" name="" />
                                        </div>
                                        <div class="col-md-12 mb-3" id="montant-filter">
                                            <label class="form-label">Montant avoir (bon d'achat)</label>
                                            <input type="text" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label class="form-label">Nombre de points requis *</label>
                                            <input type="text" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label class="form-label">Statut *</label>
                                            <select class="form-select" name="type">
                                                <option value="actifs">Actifs</option>
                                                <option value="archive">Archivé</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </section>
                </div>
           @endsection