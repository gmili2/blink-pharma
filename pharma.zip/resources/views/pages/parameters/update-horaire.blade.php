@extends('layouts.app')

@section('content')                  <div class="page-content">
                    <section class="section-client mt-3 pb-5">
                        <form action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="title">
                                        <h1>Modifier les horaires d'ouverture par défaut</h1>
                                    </div>
                                </div>
                                <div class="col-md-6 text-end">
                                    <div class="buttons">
                                        <a href="#" class="btn-hover color-green">Sauvegarder</a>
                                    </div>
                                </div>
                            </div>
                            <div class="section-form-client mt-4">
                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Lundi</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 1</label>
                                            {{-- <input type="date" class="form-control" name="" /> --}}
                                            <input type="time" class="form-control" id="appt" name="appt"
       min="09:00" max="18:00" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                    </div>
                                </div>
                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Mardi</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Mercredi</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Jeudi</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Vendredi</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Samedi</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                    </div>
                                </div>

                                <div class="block-form bg-white p-4 mb-4">
                                    <div class="section-subtitle pb-1 mb-3">
                                        <h5>Dimanche</h5>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 1</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Début 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Fin 2</label>
                                            <input type="date" class="form-control" name="" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </section>
                </div>
    @endsection