@extends('layouts.app')
@section('content')
<br/>
<div class="page-content">
                    <section class="section-client mt-3 pb-5">
                        <div class="row text-end">
                            <div class="col-md-12">
                                <div class="buttons">
                                    <a href="#" class="btn-hover color-white">Ajouter aux favoris</a>
                                    <a href="#" class="btn-hover color-white">Historique des opérations</a>
                                    <a href="{{url('addfournisseur')}}" class="btn-hover color-blue">Ajouter un nouveau fournisseur</a>
                                </div>
                            </div>
                        </div>

                        <div class="section-table-client mt-4 pt-3">
                            <div class="row filtre-client pb-1">
                                <div class="col-md-12">
                                    <div class="title-p pt-1"><h5>Liste des Fournisseurs</h5></div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-group d-flex align-items-center">
                                    <i class="bi bi-search"></i>
                                    <input type="text" style="    width: 205px;
                                    margin: 17px" class="form-control" placeholder="Search" id=recherch_produit
                                    onkeyup="recherche_produit()"
                                    name="search" />                                                </div>
                            </div>


                            <hr class="divider" />

                           
                            <table id="table" class="table table-striped" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>Fournisseurs</th>
                                        <th>Téléphone</th>
                                        <th>Ville</th>
                                        <th>Solde</th>
                                        <th>Téléchargement</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($fournisseurs as $frn)
                                    <tr>
                                        <td>{{$frn->name}}</td>
                                        <td>{{$frn->tele}}</td>
                                        <td>{{$frn->ville}}</td>
                                        <td>1 097</td>
                                        <td>
                                            <div class="status">
                                                <a href="#" class="telechargement"> <i class="bi bi-arrow-down"></i> PDF</a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="dropdown section-action">
                                                <a href="" class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i> </a>
                                                <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="{{url('showfournisseur'.$frn->id)}}">Afficher</a></li>
                                                    <li><a class="dropdown-item" href="{{url('modifyfournisseur'.$frn->id)}}">Modifier</a></li>
                                                    {{-- <li><a class="dropdown-item" href="{{url('deletefournisseur'.$frn->id)}}">Supprimer</a></li> --}}
                                                    <li>
                                                        <a class="dropdown-item" 
                                                        onclick="charger_id_produit({{$frn->id}})"
                                                        href="" data-bs-toggle="modal" data-bs-target="#search-client" >Supprimer</a>
                                                     </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                          @endforeach
                                </tbody>
                            </table>
{{ $fournisseurs->links() }}

                        </div>
                    </section>
                </div>
                <div class="modal fade vente-succes search-client" id="search-client" tabindex="-1" aria-labelledby="" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Supprimer ce fournisseur</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div>
                                <p class="text text-center mt-4">
                                   
                                </p>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-12">
                                       </div>
                                </div>
                                <form id="form1" action="deletefournisseur" method="post">
                                    @method('delete')
                                    @csrf
                                   <input type="text"  id="fr_id" hidden name="fr_id">
                                <div class="row section-footer">
                                    <div class="buttons">
                                        <a href="#" class="btn-hover color-red" class="btn-close" data-bs-dismiss="modal" aria-label="Close">Annuler</a>
        
                                        <button class="btn btn-hover color-green mx-1" data-bs-dismiss="modal" 
                                        
                                        aria-label="Close">Supprimer</button>

                                    </div>
                                </div>
                            </form>

                            </div>
                        </div>
                    </div>
                </div>
                <script>
                    function charger_id_produit(id){
                        document.getElementById("fr_id").value=id;
                    }
                    function recherche_produit(){
                                var res=document.getElementById('recherch_produit').value;
                                rout="gettable_fournisseur"+res
                    if(res=="")
                    rout="gettablee_fournisseur"
                         .then(function (response) {
                            document.getElementById("table").innerHTML= response.data;
                    
                           
                         })
                         .catch(function (error) {
                             // handle error
                             console.log(error);
                         });
                                
                               }
                </script>
                @endsection