<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Produitssortieconfrere extends Model
{
    //
}
