<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Prixproduit extends Model
{
    //
}
