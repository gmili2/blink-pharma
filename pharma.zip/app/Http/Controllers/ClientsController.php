<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;
use Illuminate\Support\Facades\DB;
use Auth;

class ClientsController extends Controller
{
public function index()
{

    $clients= DB::table('clients')
    ->select('clients.*')
    ->where('clients.creer_par',Auth::User()->id)
    ->whereNull('clients.deleted_at')
    ->paginate(2); 
    return view('pages/client/client',
    compact('clients'));
}
public function get_clientbynom($nom)
{

    $clients= DB::table('clients')
    ->select('clients.*')
    ->where('clients.creer_par',Auth::User()->id)
    ->whereNull('clients.deleted_at')
    ->where('clients.name', 'like', '%'.$nom.'%')
    ->paginate(2); 
    $paginate=0;

    return view('pages/client/table-client',compact('clients'),compact('paginate'));
}


public function get_client()
{

    $clients= DB::table('clients')
    ->select('clients.*')
    ->where('clients.creer_par',Auth::User()->id)
    ->whereNull('clients.deleted_at')
    ->paginate(2); 
    $paginate=0;
    return view('pages/client/table-client',compact('clients'),compact('paginate'));
}



public function store(Request $req)
{
    $client=new Client();
    DB::beginTransaction();
    try{
        if($req->image!=null)
        {
        $image = time() . '-' . $req->nom . '.' . $req->image->extension();
        $req->image->move(public_path('images'), $image);
        $client->image = $image;
        } 
        $client->name=$req->nom;
        $client->cin=$req->cin;
        $client->cnss=$req->cnss;
        $client->email=$req->email;
        $client->type=$req->type;
        $client->tele=$req->tel;
        $client->ville=$req->ville;
        $client->adresse=$req->adresse;
        $client->code_postale=$req->codeposal;
        $client->plafan_credit=$req->plafancredit;
        $client->organisme=$req->organisme;
        $client->num_immatriculation=$req->num_immatriculation;
        $client->num_affiliation=$req->num_affiliation;
        $client->description=$req->description;
        $client->creer_par=Auth::user()->id;
        $client->save();
        DB::commit();
        session()->flash('success','Client ajouté avec succés');	
        return redirect('clients');
    }
        catch(QueryException $ex){
            DB::rollBack();
        $req->session()->flash('warning', 'erreur base donnée');
            return redirect('clients');
        }  
}


public function delete(Request $req)
{
    DB::beginTransaction();
    $id= $req->client_id;
    try{
    $client = Client::find($id);
    $client->delete();
    DB::commit();
    session()->flash('success','Client supprimé avec succés');	
    return redirect('clients');
}
catch(QueryException $ex){
    DB::rollBack();
session()->flash('warning', 'erreur base donnée');
    return redirect('clients');
}  
}
public function update(Request $req,$id)
{
    DB::beginTransaction();
    try{
    $client = Client::find($id);
    if($req->image!=null)
    {
    $image = time() . '-' . $req->nom . '.' . $req->image->extension();
    $req->image->move(public_path('images'), $image);
    $client->image = $image;
    } 
    $client->name=$req->nom;
    $client->cin=$req->cin;
    $client->cnss=$req->cnss;
    $client->email=$req->email;
    $client->type=$req->type;
    $client->tele=$req->tel;
    $client->ville=$req->ville;
    $client->adresse=$req->adresse;
    $client->code_postale=$req->codeposal;
    $client->plafan_credit=$req->plafancredit;
    $client->organisme=$req->organisme;
    $client->num_immatriculation=$req->num_immatriculation;
    $client->num_affiliation=$req->num_affiliation;
    $client->description=$req->description;
    $client->creer_par=Auth::user()->id;
    $client->save();
    DB::commit();
    session()->flash('success','Client modifié avec succés');	
    return redirect('clients');}
catch(QueryException $ex){
    DB::rollBack();
session()->flash('warning', 'erreur base donnée');
    return redirect('clients');
}  
}


public function showclient($id)
{

  
    $produits = DB::table('venteproduits')
    ->join('ventes', 'venteproduits.ventes_id', '=', 'ventes.id')
    ->join('produits', 'venteproduits.produits_id', '=', 'produits.id')
    ->join('clients', 'ventes.client_id', '=', 'clients.id')
    ->where('ventes.client_id', $id)
    ->whereNull('ventes.deleted_at')
    ->whereNull('venteproduits.deleted_at')
    ->select('ventes.*',"produits.*","venteproduits.*",'clients.name as nom_client')
    ->get(); 

    $credit = DB::table('ventes')
    ->select('clients.id',DB::raw('SUM(ventes.montant_credit) as credit_total'))
    ->groupBy('ventes.montant_credit','clients.id')
    ->join('clients', 'ventes.client_id', '=', 'clients.id')
    ->where('ventes.creer_par',Auth::User()->id)
    ->where('ventes.client_id', $id)
    ->whereNull('ventes.deleted_at')
    
    ->get();

        $ventes= DB::table('ventes')
        ->select('ventes.*','clients.name as nom_client')        
        ->join('clients', 'ventes.client_id', '=', 'clients.id')
        ->where('ventes.creer_par',Auth::User()->id)
        ->where('ventes.client_id', $id)
        ->whereNull('ventes.deleted_at')
        ->get();
        // dd( $produits , $ventes);
    $clients = Client::find($id);
    return view('pages/client/informationclient',
    ['produits' => $produits,
    'clients' => $clients,
    'ventes' => $ventes,
    'credit' => $credit]


);
    
    // compact('clients'),compact('ventes'),compact('produits'));
}

public function modifyclient($id)
{
    $clients = Client::find($id);
    return view('pages/client/clientdetails',compact('clients'));
}



}
