<?php

namespace App\Http\Controllers;
use App\Client;
use App\Exports\ClientExport;
use App\Exports\ProduitExport;
use App\Exports\ConfrereExport;
use App\Exports\FournisseurExport;
use App\Exports\SortieConfrereExport;
use App\Exports\EntrerConfrereExport;
use App\Exports\VenteExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;

class Exporatation_CSV extends Controller
{
//    public function ExportClient(){
//     echo 'noooooooooooooooooooooooooooo';
//     return Excel::download(new UsersExport, 'Client.csv');
//     }
//    public function ExportProduit(){
//      echo 'ffiofuzfd';
//         return Excel::download(new ProduitExport, 'Produit.csv');
//         }
//     public function ExportConfrere(){
//             return Excel::download(new ConfrereExport, 'Confrere.csv');
//             }
//      public function ExportFournisseur(){
//                 return Excel::download(new FournisseurExport, 'Fournisseur.csv');
//                 }




    public function Exporter(){
        // dd('heloooooooooo');
        return view('pages.exportation.exportation');

    }
    public function ExporterData(Request $req){

        $choix=$req->post('table_choisie');

        if($choix== "client"){
            return Excel::download(new ClientExport, 'Client.csv');

        }
        else if ($choix=="fournisseur"){
            return Excel::download(new FournisseurExport, 'Fournisseur.csv');
        }
        else if ($choix=="Confrere"){
            return Excel::download(new ConfrereExport, 'Confrere.csv');
        }
        else if($choix =="Produit"){
            return Excel::download(new ProduitExport, 'Produit.csv');
        }
        else if ($choix == "Vente"){
            return Excel::download(new VenteExport, 'Vente.csv');

        }
        else if ($choix=="EntrerConfere"){
            return Excel::download(new EntrerConfrereExport ,'entrerConfrere.csv');
        }
        else if ($choix =="SortieConfere"){
            return Excel::download(new SortieConfrereExport,'sortieConfrere.csv');
        }
        else {
            echo 'zkmzeff   ahmed';
        }
     return redirect('Exportation.exportation');

    }
}
