<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // dd("j");
        $ventes= DB::table('ventes')
        ->select('ventes.*','clients.name as nom_client')
        ->join('clients', 'ventes.client_id', '=', 'clients.id')
        ->where('ventes.creer_par',Auth::User()->id)
        ->whereNull('ventes.deleted_at')
        ->paginate(5);
        $produits= DB::table('produits')
        ->select('produits.*')
        ->where('produits.creer_par',Auth::User()->id)
        ->whereNull('produits.deleted_at')
        ->count();
        // dd('');
         return view('home'
         ,compact('ventes'),compact('produits'));
    }
    public function get_vente(){
        $ventes= DB::table('ventes')
        ->select('ventes.*','clients.name as nom_client')
        ->join('clients', 'ventes.client_id', '=', 'clients.id')
        ->where('ventes.creer_par',Auth::User()->id)
        ->whereNull('ventes.deleted_at')
        ->paginate(5);
        // $produits= DB::table('produits')
        // ->select('produits.*')
        // ->where('produits.creer_par',Auth::User()->id)
        // ->whereNull('produits.deleted_at')
        // ->count();
        $paginate=1;
         return view('table-produit-home'
         ,compact('ventes'),compact('paginate'));
    }
    public function get_vente_bynom($nom){
        $ventes= DB::table('ventes')
        ->select('ventes.*','clients.name as nom_client')
        ->join('clients', 'ventes.client_id', '=', 'clients.id')
        ->where('ventes.creer_par',Auth::User()->id)
        ->where('ventes.creer_par',Auth::User()->id)
        ->where('clients.name', 'like', '%'.$nom.'%')
        ->get();
        // $produits= DB::table('produits')
        // ->select('produits.*')
        // ->where('produits.creer_par',Auth::User()->id)
        // ->whereNull('produits.deleted_at')
        // ->count();
        $paginate=0;

         return view('table-produit-home'
         ,compact('ventes'),compact('paginate'));
    }


    
}
