<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;
use Illuminate\Support\Facades\DB;
use Auth;
use PDF;
class PdfContoller extends Controller
{

    public function facture_vente($id){
        $facture = DB::table('venteproduits')
        ->join('ventes', 'venteproduits.ventes_id', '=', 'ventes.id')
        ->join('produits', 'venteproduits.produits_id', '=', 'produits.id')
        ->join('clients', 'ventes.client_id', '=', 'clients.id')
        ->where('ventes.id', $id)
        ->whereNull('ventes.deleted_at')
        ->whereNull('venteproduits.deleted_at')
        ->select('ventes.*',"produits.*","venteproduits.*",'clients.name as nom_client','clients.adresse as adressclient')
        ->get();
        $date= date("Y/m/d") ;
                $data = [
                'facture' => $facture,
                'date'=> $date,
                        ];
          $pdf = PDF::loadView('facture', $data);
          return $pdf->stream('document.pdf');

    }

    
}
