<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Retoursurventeproduit extends Model
{
    //
}
