      
                

                <?php $__env->startSection('content'); ?>
                <!-- partial -->
                <div class="page-content">
                    <section class="section-produit mt-3 pb-5">
                        <div class="row text-end">
                            <div class="col-md-12">
                                <div class="buttons">
                                    <a href="#" class="btn-hover color-white">Ajouter aux favoris</a>
                                    
                                    <a href="ajouterproduit" class="btn-hover color-blue">Ajouter un nouveau produit</a>
                                </div>
                            </div>
                        </div>

                        <div class="section-table-product mt-4 pt-3">
                            <div class="row filtre-product pb-1">
                                <div class="col-md-6">
                                    <div class="title-p pt-1"><h5>Liste des produits</h5></div>
                                </div>

                                <div class="col-md-6">
                                    <div class="status-actif">
                                        <div class="status">
                                            <span class="on"><i class="bi bi-circle-fill"></i> Oui</span>
                                        </div>
                                        <div class="status">
                                            <span class="off"><i class="bi bi-circle-fill"></i> Non</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <div class="form-group d-flex align-items-center">
                                    <i class="bi bi-search"></i>
                                    <input type="text" style="    width: 205px;
                                    margin: 17px" class="form-control" placeholder="Search" id=recherch_produit
                                    onkeyup="recherche_produit()"
                                    name="search" />                                                </div>
                            </div>
                            <div id="table2">
                            <table id="table" class="table table-striped" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>Est actif</th>
                                        <th>Produit</th>
                                        <th>Catégorie</th>
                                        <th>Forme galénique</th>
                                        <th>PPV</th>
                                        <th>PPH</th>
                                        <th>Code barre</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  
                                    <tr>
                                        <td>
                                            <div class="status">
                                                <span <?php if($produit->active==1): ?>
                                                    class="on"
                                                    <?php else: ?>
                                                    class="off"
                                                <?php endif; ?> ><i class="bi bi-circle-fill"></i></span>
                                            </div>
                                        </td>
                                        <td><?php echo e($produit->name); ?></td>
                                        <td><?php echo e($produit->nameclasse); ?></td>
                                        <td><?php echo e($produit->nameform); ?></td>
                                        <td><?php echo e($produit->PPV); ?></td>
                                        <td><?php echo e($produit->PPH); ?></td>
                                        <td><?php echo e($produit->code_bare); ?></td>
                                        <td>
                                            <div class="dropdown section-action">
                                                <a href="" class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i> </a>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item" href="informationproduct<?php echo e($produit->id); ?>">Afficher</a></li>
                                                    <li><a class="dropdown-item" href="modifierproduitformule<?php echo e($produit->id); ?>">Modifier</a></li>
                                                    <?php if($produit->active==1): ?>
                                                    <li><a class="dropdown-item" href="desactiverproduit<?php echo e($produit->id); ?>">Désactiver</a></li>
                                                        <?php else: ?>
                                                    <li><a class="dropdown-item" href="avtiverproduit<?php echo e($produit->id); ?>">Activer</a></li>
                                                    <?php endif; ?>
                                                    <li>
                                                        <a class="dropdown-item" 
                                                        onclick="charger_id_produit(<?php echo e($produit->id); ?>)"
                                                        href="" data-bs-toggle="modal" data-bs-target="#search-client" >Supprimer</a>
                                                     </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 
                                </tbody>

                            </table>
                            <?php echo e($produits->links()); ?>

</div>

                        </div>
                               
                          </section>
                </div>
                <div class="modal fade vente-succes search-client" id="search-client" tabindex="-1" aria-labelledby="" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Supprimer ce produit</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div>
                                <p class="text text-center mt-4">
                                   
                                </p>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-12">
                                       </div>
                                </div>
                                <form id="form1" action="supprimerproduit" method="post">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                   <input type="text" hidden id="produit_id" name="produit_id">
                                <div class="row section-footer">
                                    <div class="buttons">
                                        <a href="#" class="btn-hover color-red" class="btn-close" data-bs-dismiss="modal" aria-label="Close">Annuler</a>
        
                                        <button class="btn btn-hover color-green mx-1" data-bs-dismiss="modal" 
                                        
                                        aria-label="Close">Supprimer</button>

                                    </div>
                                </div>
                            </form>

                            </div>
                        </div>
                    </div>
                </div>
                <script>
        //    recherche_produit();
                   

                //    document.getElementById('table').dataTable({searching: false, paging: false, info: false});


                    function charger_id_produit(id){
                        document.getElementById("produit_id").value=id;
                    }
                    function recherche_produit(){
            var res=document.getElementById('recherch_produit').value;
            rout="get_produit"+res
            if(res==""){
    // document.getElementById("table3").hidden=false; 
    // document.getElementById("table").hidden=false; 

    rout="gett_produit"

} 

            axios.get(rout)
     .then(function (response) {
        document.getElementById("table").innerHTML= response.data;

       
     })
     .catch(function (error) {
         console.log(error);
     });
   
           }

                </script>
                <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Anouar Gm\Desktop\upwork\testserv\pharma\resources\views/pages/products/product.blade.php ENDPATH**/ ?>