<table id="table" class="table table-striped" style="width: 100%;">
    <thead>
        <tr>
            <th>Est actif</th>
            <th>Produit</th>
            <th>Catégorie</th>
            <th>Forme galénique</th>
            <th>PPV</th>
            <th>PPH</th>
            <th>Code barre</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
        <tr>
            <td>
                <div class="status">
                    <span <?php if($produit->active==1): ?>
                        class="on"
                        <?php else: ?>
                        class="off"
                    <?php endif; ?> ><i class="bi bi-circle-fill"></i></span>
                </div>
            </td>
            <td><?php echo e($produit->name); ?></td>
            <td><?php echo e($produit->nameclasse); ?></td>
            <td><?php echo e($produit->nameform); ?></td>
            <td><?php echo e($produit->PPV); ?></td>
            <td><?php echo e($produit->PPH); ?></td>
            <td><?php echo e($produit->code_bare); ?></td>
            <td>
                <div class="dropdown section-action">
                    <a href="" class="dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots-vertical"></i> </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="informationproduct<?php echo e($produit->id); ?>">Afficher</a></li>
                        <li><a class="dropdown-item" href="modifierproduitformule<?php echo e($produit->id); ?>">Modifier</a></li>
                        <?php if($produit->active==1): ?>
                        <li><a class="dropdown-item" href="desactiverproduit<?php echo e($produit->id); ?>">Désactiver</a></li>
                            <?php else: ?>
                        <li><a class="dropdown-item" href="avtiverproduit<?php echo e($produit->id); ?>">Activer</a></li>
                        <?php endif; ?>
                        <li>
                            <a class="dropdown-item" 
                            onclick="charger_id_produit(<?php echo e($produit->id); ?>)"
                            href="" data-bs-toggle="modal" data-bs-target="#search-client" >Supprimer</a>
                         </li>
                    </ul>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     
    </tbody>
</table>

<?php /**PATH C:\Users\Anouar Gm\Desktop\upwork\testserv\pharma\resources\views/pages/products/table.blade.php ENDPATH**/ ?>